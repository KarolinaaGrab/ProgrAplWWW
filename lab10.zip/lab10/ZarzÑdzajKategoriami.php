<?php

class ZarzadzajKategoriami {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function DodajKategorie($nazwa, $matka = 0) {
        $sql = "INSERT INTO categories (parent_id, name) VALUES (?, ?)";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bind_param("is", $matka, $nazwa);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "Błąd przy dodawaniu kategorii: " . $this->db->error;
        }
    }

    public function UsunKategorie($id) {
        $sql = "DELETE FROM categories WHERE id = ?";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "Błąd przy usuwaniu kategorii: " . $this->db->error;
        }
    }

    public function EdytujKategorie($id, $nazwa, $matka) {
        $sql = "UPDATE categories SET name = ?, parent_id = ? WHERE id = ?";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bind_param("sii", $nazwa, $matka, $id);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "Błąd przy edytowaniu kategorii: " . $this->db->error;
        }
    }

    public function PokazKategorie() {
        $sql = "SELECT * FROM categories WHERE parent_id = 0";
        if ($result = $this->db->query($sql)) {
            while ($row = $result->fetch_assoc()) {
                echo "Kategoria Główna: " . $row['name'] . "<br/>";
                $this->pokazPodkategorie($row['id']);
            }
            $result->free();
        } else {
            echo "Błąd przy wyświetlaniu kategorii: " . $this->db->error;
        }
    }

    private function pokazPodkategorie($parentId) {
        $sql = "SELECT * FROM categories WHERE parent_id = ?";
        if ($stmt = $this->db->prepare($sql)) {
            $stmt->bind_param("i", $parentId);
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                echo " - Podkategoria: " . $row['name'] . "<br/>";
            }
            $stmt->close();
        } else {
            echo "Błąd przy wyświetlaniu podkategorii: " . $this->db->error;
        }
    }
}

?>