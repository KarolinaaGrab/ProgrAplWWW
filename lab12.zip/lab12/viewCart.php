<?php
session_start();
include 'cfg.php';

$totalItems = 0;
$totalPrice = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta viewport="width=device-width, initial-scale=1.0">
    <title>Your Shopping Cart</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }
        .container {
            display: flex;
            justify-content: space-around;
            padding: 20px;
        }
        .product, .cart {
            width: 45%;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        .cart-item, .product div {
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }
        form {
            display: flex;
            align-items: center;
        }
        input[type='number'] {
            padding: 6px;
            width: 60px;
            margin-right: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        button {
            background: #5cb85c;
            color: white;
            border: none;
            padding: 8px 15px;
            margin: 5px 0;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #4cae4c;
        }
        a {
            color: #5cb85c;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="product">
            <h2>Products</h2>
            <?php
            $result = mysqli_query($link, "SELECT * FROM products");
            while ($row = mysqli_fetch_assoc($result)) {
                $finalPrice = $row['netto_value'] + ($row['netto_value'] * $row['vat'] / 100);
                echo "<div>";
                echo "<h3>".$row['title']." - Netto: $".$row['netto_value']." - VAT: ".$row['vat']."% - Final: $".$finalPrice."</h3>";
                echo "<p>".$row['description']."</p>";
                echo "<a href='addToCart.php?id=".$row['id']."'>Add to Cart</a>";
                echo "</div>";
            }
            ?>
        </div>

        <div class="cart">
            <h2>Your Cart</h2>
            <?php
            if (!empty($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $productId => $quantity) {
                    $productQuery = mysqli_query($link, "SELECT title, netto_value, vat, amount FROM products WHERE id = $productId");
                    $productData = mysqli_fetch_assoc($productQuery);

                    $finalPrice = $productData['netto_value'] + ($productData['netto_value'] * $productData['vat'] / 100);
                    $totalItemPrice = $quantity * $finalPrice;
                    $totalPrice += $totalItemPrice;
                    $totalItems += $quantity;

                    echo "<div class='cart-item'>";
                    echo "<p>".$productData['title']." - Quantity: ".$quantity." - Price per item: $".$productData['netto_value']." - VAT: ".$productData['vat']."% - Total: $".$totalItemPrice."</p>";
                    echo "<form action='updateCart.php' method='post'>";
                    echo "<input type='number' name='quantity' value='".$quantity."' min='0' max='".$productData['amount']."' required>";
                    echo "<input type='hidden' name='productId' value='".$productId."'>";
                    echo "<button type='submit'>Update</button>";
                    echo "</form>";
                    echo "</div>";
                }
                echo "<p>Total Items: ".$totalItems."</p>";
                echo "<p>Total Price: $".$totalPrice."</p>";
            } else {
                echo "<p>Your cart is empty.</p>";
            }
            ?>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.cart form').forEach(function(form) {
                form.onsubmit = function() {
                    var quantity = parseInt(this.quantity.value);
                    var max = parseInt(this.quantity.max);

                    if (quantity < 0) {
                        alert('Quantity cannot be negative');
                        return false;
                    } else if (quantity > max) {
                        alert('Cannot exceed available quantity');
                        return false;
                    }

                    return true;
                };
            });
        });
    </script>
</body>
</html>
