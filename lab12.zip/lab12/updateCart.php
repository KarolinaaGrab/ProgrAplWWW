<?php
session_start();
include 'cfg.php';

if(isset($_POST['productId']) && isset($_POST['quantity'])) {
    $productId = $_POST['productId'];
    $quantity = (int) $_POST['quantity'];

    if($quantity == 0) {
        unset($_SESSION['cart'][$productId]);
    } else {
        $_SESSION['cart'][$productId] = $quantity;
    }
}

header('Location: viewCart.php');
?>
