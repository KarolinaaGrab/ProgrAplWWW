<link rel="stylesheet" href="../css/cms.css">

<?php 
    require_once('../contact.php');

    session_start(); # rozpoczęcie sesji
    if (!isset($_SESSION['admin_logged_in'])){   # jeśli sesja nie jest ustawiona na zalogowanego użytkownika, użytkownik jest przekierowywany na stronę logowania
        header('Location: log_in.php'); # adres strony logowania
        exit();
    }
    require_once('admin.php');
    require_once('../cfg.php'); # import pliku konfiguracyjnego

    global $link;

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CMS</title>
    <link rel="stylesheet" href="../css/cms.css"> <!-- Link to your existing CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .admin-panel {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }
        .admin-panel button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            margin: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .admin-panel button:hover {
            background-color: #0056b3;
        }
        .admin-panel a {
            color: #fff;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="admin-panel">
        <h1>Admin Panel</h1>
        <button><a href="log_out.php">Wyloguj się</a></button>
        <button><a href="../contact_page.php">Wyślij wiadomosc</a></button>
        <button><a href="manage_subpages.php">Zarządzaj Podstronami</a></button>
        <button><a href="manage_categories_products.php">Zarządzaj Kategoriami i Produktami</a></button>
    </div>
</body>
</html>