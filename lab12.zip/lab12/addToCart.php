<?php
session_start();
include 'cfg.php';

if(!isset($_SESSION['cart'])){
    $_SESSION['cart'] = array();
}

if(isset($_GET['id'])){
    $productId = $_GET['id'];
    $productQuery = mysqli_query($link, "SELECT amount FROM products WHERE id = $productId");
    $productData = mysqli_fetch_assoc($productQuery);

    if($productData){
        $currentCartAmount = isset($_SESSION['cart'][$productId]) ? $_SESSION['cart'][$productId] : 0;
        if($productData['amount'] > $currentCartAmount){
            if(isset($_SESSION['cart'][$productId])){
                $_SESSION['cart'][$productId]++;
            } else {
                $_SESSION['cart'][$productId] = 1;
            }
            header('Location: viewCart.php');
        } else {
            echo "<script>alert('No more available items'); window.location.href='viewCart.php';</script>";
        }
    } else {
        echo "Product not found.";
    }
} else {
    echo "Product not found.";
}
?>
